// AsyncServerSocket.cpp : implementation file
//

#include "pch.h"
#include "SocketLibrary.h"
#include "AsyncServerSocket.h"
#include "ISocketOwner.h"


// CAsyncServerSocket

DEFINEDLL CAsyncServerSocket :: CAsyncServerSocket ( )
{

}

DEFINEDLL CAsyncServerSocket :: CAsyncServerSocket ( int nPort, CString sIPAddress, int nWaitCount)
{
	m_nPort = nPort ;
	m_sIPAddres = sIPAddress ;
	m_nWaitCount = nWaitCount ; 
}

DEFINEDLL CAsyncServerSocket :: ~CAsyncServerSocket()
{
}

DEFINEDLL BOOL CAsyncServerSocket :: CreateServerSocket( )
{
	return Create ( m_nPort, SOCK_STREAM, 
		FD_READ | FD_WRITE | FD_OOB | FD_ACCEPT | FD_CONNECT | FD_CLOSE, m_sIPAddres ) ;
}

DEFINEDLL BOOL CAsyncServerSocket :: BeginListening ( )
{
	return Listen ( m_nWaitCount ) ;
}

DEFINEDLL void CAsyncServerSocket :: SetSocketOwner(ISocketOwner* pSocketOwner)
{
	m_pSocketOwner = pSocketOwner;
}

/*Event Handers--------------------------------------------------------------------*/

void CAsyncServerSocket :: OnAccept ( int nErrorCode )
{
	if ( NULL != m_pSocketOwner )
		m_pSocketOwner -> OnSocketAccept( nErrorCode ) ;
	CAsyncSocket :: OnAccept ( nErrorCode ) ;
}


void CAsyncServerSocket :: OnClose ( int nErrorCode )
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner -> OnSocketClose( nErrorCode ) ;
	CAsyncSocket :: OnClose ( nErrorCode ) ;
}

void CAsyncServerSocket :: OnConnect ( int nErrorCode )
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketConnet ( nErrorCode ) ;
	CAsyncSocket::OnConnect( nErrorCode ) ;
}
