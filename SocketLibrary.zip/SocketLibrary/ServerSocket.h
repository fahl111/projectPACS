#pragma once

// CServerSocket command target

#if defined( BUILD_DLL )/*Just a name*/
#define DEFINEDLL __declspec(dllexport)//This is for the DLL  project
#else
#define DEFINEDLL __declspec(dllimport) //This is for the cosuming Applicatoin
#endif
class ISocketOwner ;

class CServerSocket : public CSocket
{
public:
	DEFINEDLL CServerSocket(  ) ;

	DEFINEDLL virtual ~CServerSocket(  );

	DEFINEDLL CServerSocket ( int nPort, CString sIPAddress, int nWaitCount ) ;

	/// <summary>
	/// Create the server socket
	/// </summary>
	/// <returns></returns>
	DEFINEDLL BOOL CreateServerSocket();

	DEFINEDLL BOOL BeginListening();

	DEFINEDLL void SetSocketOwner(ISocketOwner* pSocketOwner);

	/*Event Handers--------------------------------------------------------------------*/

	virtual void OnAccept(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void OnConnect(int nErrorCode);

protected:
	//CWinThread m_pSocketOwner = NULL ; //I can code like this, But if i am managing the socket from a window, i have to use another variable.
	ISocketOwner* m_pSocketOwner = NULL;
	int m_nPort = 20;

	int m_nWaitCount = 5;/*The total Connect request queue size*/

	CString m_sIPAddres = _T("127.0.0.1"); //Local host
};


