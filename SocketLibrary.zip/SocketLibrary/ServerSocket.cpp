// ServerSocket.cpp : implementation file
//

#include "pch.h"
#include "SocketLibrary.h"
#include "ServerSocket.h"
#include "ISocketOwner.h"

// CServerSocket

DEFINEDLL CServerSocket::CServerSocket()
{
}

DEFINEDLL CServerSocket::~CServerSocket()
{
}

DEFINEDLL CServerSocket::CServerSocket(int nPort, CString sIPAddress, int nWaitCount)
{
	m_nPort = nPort;
	m_sIPAddres = sIPAddress;
	m_nWaitCount = nWaitCount;
}

DEFINEDLL BOOL CServerSocket::CreateServerSocket( )
{
	return Create(m_nPort, SOCK_STREAM, m_sIPAddres ) ;
}

DEFINEDLL BOOL CServerSocket::BeginListening()
{
	return Listen(m_nWaitCount);
}

DEFINEDLL void CServerSocket::SetSocketOwner(ISocketOwner* pSocketOwner)
{
	m_pSocketOwner = pSocketOwner;
}

/*Event Handers--------------------------------------------------------------------*/

void CServerSocket::OnAccept(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketAccept(nErrorCode);
	CSocket::OnAccept(nErrorCode);
}


void CServerSocket::OnClose(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketClose(nErrorCode);
	CSocket::OnClose(nErrorCode);
}

void CServerSocket::OnConnect(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketConnet(nErrorCode);
	CSocket::OnConnect(nErrorCode);
}
