#pragma once

#if defined( BUILD_DLL )
#define DEFINEDLL __declspec(dllexport)
#else
#define DEFINEDLL __declspec(dllimport)
#endif
#include "ISocketOwner.h"

class CAsyncClientSocket : public CAsyncSocket
{
public:
	DEFINEDLL CAsyncClientSocket( ) ;
	
	DEFINEDLL CAsyncClientSocket( int nPort, CString sIPAddress ) ;
	
	DEFINEDLL BOOL CreateClientSocket(  ) ;

	DEFINEDLL BOOL ConnectToServer( int nPort, CString sIPAddress ) ;

	DEFINEDLL BOOL SendData ( CString sDataToSend ) ;

	DEFINEDLL BOOL ReceiveData ( CString & sDataToReceive ) ;

	DEFINEDLL virtual ~CAsyncClientSocket( ) ;

	DEFINEDLL void SetSocketOwner ( ISocketOwner* pSocketOwner ) ;
	
	/*Event Handers--------------------------------------------------------------------*/

	virtual void OnClose ( int nErrorCode ) ;

	virtual void OnReceive ( int nErrorCode ) ;

	virtual void OnSend ( int nErrorCode ) ;

	virtual void Serialize ( CArchive& ar ) ;

	virtual void OnConnect(int nErrorCode);

private :

	ISocketOwner* m_pSocketOwner = NULL ;

	int m_nPort = 20 ;

	CString m_sIPAddress = _T( "127.0.0.1" ) ;

};


