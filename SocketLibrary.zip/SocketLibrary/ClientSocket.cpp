// ClientSocket.cpp : implementation file
//

#include "pch.h"
#include "SocketLibrary.h"
#include "ClientSocket.h"


// CClientSocket

DEFINEDLL CClientSocket::CClientSocket()
{
}

DEFINEDLL CClientSocket :: ~CClientSocket()
{
}

DEFINEDLL CClientSocket::CClientSocket(int nPort, CString sIPAddress)
{
	m_nPort = nPort;
	m_sIPAddress = sIPAddress;
}

DEFINEDLL BOOL CClientSocket::CreateClientSocket()
{
	return Create();
}

DEFINEDLL BOOL CClientSocket::ConnectToServer(int nPort, CString sIPAddress)
{
	return Connect(sIPAddress, nPort);
}

BOOL CClientSocket::SendData(CString sDataToSend)//This is a Version with CString object, normal Send function take buffer
{
	int nCount = sDataToSend.GetLength();
	char* strToSend = new char(nCount);
	strcpy(strToSend, CStringA(sDataToSend).GetString());
	return this/*Just to show, Not needed*/ -> Send/*Direct Socket Function*/(strToSend, nCount);
}

BOOL CClientSocket::ReceiveData(CString& sDataToReceive)
{
	char* buff = new char[2048];
	int nRead;
	nRead = Receive(buff, 2047);

	while (nRead != 0 && nRead != -1)
	{
		buff[nRead] = _T('\0'); //terminate the string
		CString szTemp(buff);
		sDataToReceive += szTemp; // m_strRecv is a CString declared
							 // in CMyAsyncSocket
		if (szTemp.CompareNoCase(_T("bye")) == 0)
		{
			ShutDown();
		}
		
		if (nRead == 2047) //If data pending Read again
			nRead = Receive(buff, 2047);
		else nRead = 0 ; //Exit the loop 
	}
	return 0;
}

DEFINEDLL void CClientSocket::SetSocketOwner(ISocketOwner* pSocketOwner)
{
	m_pSocketOwner = pSocketOwner;
}


/*Event Handers--------------------------------------------------------------------*/
void CClientSocket::OnConnect(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketConnet(nErrorCode);
	CSocket::OnConnect(nErrorCode);
}

void CClientSocket::OnClose(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketClose(nErrorCode);
	CSocket::OnClose(nErrorCode);
}

void CClientSocket::OnReceive(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketReceive(nErrorCode);
	CSocket::OnReceive(nErrorCode);
}


void CClientSocket::OnSend(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketSend(nErrorCode);
	CSocket::OnSend(nErrorCode);
}


void CClientSocket::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
	}
	else
	{	// loading code
	}
}

