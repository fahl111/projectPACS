#include "pch.h"
#include "DLLTestingClass.h"

DEFINEDLL CDLLTestingClass::CDLLTestingClass()
{
}

DEFINEDLL CDLLTestingClass::~CDLLTestingClass()
{
}

DEFINEDLL CString CDLLTestingClass :: FirstDLLFunction ( CString sValue )
{
    return _T("Welcom to - ") + sValue ;
}
