// AsyncClientSocket.cpp : implementation file
//

#include "pch.h"
#include "SocketLibrary.h"
#include "AsyncClientSocket.h"
#include <vector>
#include <string>


// CAsyncClientSocket

DEFINEDLL CAsyncClientSocket :: CAsyncClientSocket( )
{

}

DEFINEDLL CAsyncClientSocket :: CAsyncClientSocket ( int nPort, CString sIPAddress )
{
	m_nPort = nPort ;
	m_sIPAddress = sIPAddress ;
}

DEFINEDLL BOOL CAsyncClientSocket :: CreateClientSocket ( )
{
	return Create( ) ;
}

DEFINEDLL BOOL CAsyncClientSocket :: ConnectToServer ( int nPort, CString sIPAddress )
{
	return Connect ( sIPAddress, nPort ) ;
}

BOOL CAsyncClientSocket :: SendData ( CString sDataToSend ) 
{ 
	int nCount = sDataToSend.GetLength();
	char* strToSend = new char(nCount);
	strcpy(strToSend, CStringA(sDataToSend).GetString());
	return Send(strToSend, nCount ) ;
}

BOOL CAsyncClientSocket :: ReceiveData ( CString & sDataToReceive ) 
{
	char * buff = new char [1024];
	int nRead;
	nRead = Receive(buff, 1023);

	while ( nRead != 0 && nRead != -1  )
	{
		buff[nRead] = _T('\0'); //terminate the string
		CString szTemp(buff);
		sDataToReceive += szTemp; // m_strRecv is a CString declared
							 // in CMyAsyncSocket
		if (szTemp.CompareNoCase(_T("bye")) == 0)
		{
			ShutDown();
		}
		nRead = Receive ( buff, 1023 ) ;
	}
	return 0 ;
}

DEFINEDLL CAsyncClientSocket :: ~CAsyncClientSocket()
{
}

DEFINEDLL void CAsyncClientSocket :: SetSocketOwner ( ISocketOwner* pSocketOwner )
{
	m_pSocketOwner = pSocketOwner ; 
}


/*Event Handers--------------------------------------------------------------------*/
void CAsyncClientSocket::OnConnect(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketConnet(nErrorCode);
	CAsyncSocket::OnConnect(nErrorCode);
}

void CAsyncClientSocket::OnClose(int nErrorCode)
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketClose( nErrorCode ) ;
	CAsyncSocket::OnClose(nErrorCode);
}

void CAsyncClientSocket :: OnReceive ( int nErrorCode )
{
	if (NULL != m_pSocketOwner)
		m_pSocketOwner->OnSocketReceive ( nErrorCode ) ;
	CAsyncSocket::OnReceive(nErrorCode);
}


void CAsyncClientSocket :: OnSend ( int nErrorCode )
{
	if ( NULL != m_pSocketOwner )
		m_pSocketOwner -> OnSocketSend ( nErrorCode ) ;
	CAsyncSocket::OnSend(nErrorCode);
}


void CAsyncClientSocket::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
	}
	else
	{	// loading code
	}
}


