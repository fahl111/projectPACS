#pragma once

#if defined( BUILD_DLL )
#define DEFINEDLL __declspec(dllexport)
#else
#define DEFINEDLL __declspec(dllimport)
#endif

//An Abstract Class - Used as an Interface - For defining Sockect owner object, Socket owner can be a Window, thread or any othere class
//Socket owner must  impliment ISocketOwner Inteface
DEFINEDLL class ISocketOwner //This is used as  a interface, for socket class to store the different type of 
{
public :
	DEFINEDLL virtual void OnSocketConnet( int nErrorCode ) ; //With minimal implementations, so that i can avoid ovveriding in Extended classes if they dont want
		
	DEFINEDLL virtual void OnSocketAccept( int nErrorCode ) ;

	DEFINEDLL virtual void OnSocketClose ( int nErrorCode ) ;

	DEFINEDLL virtual void OnSocketSend ( int nErrorCode ) ;

	DEFINEDLL virtual void OnSocketReceive ( int nErrorCode ) ;

	/// <summary>
	/// This pure virtual function make sure to restrict the object creation of SocketOwner class
	/// </summary>
	DEFINEDLL virtual void RestriectObjectCreation( ) = 0 ;
} ;

