#pragma once


#if defined( BUILD_DLL )
#define DEFINEDLL __declspec(dllexport)
#else
#define DEFINEDLL __declspec(dllimport)
#endif

class  CDLLTestingClass
{
public :
	DEFINEDLL CDLLTestingClass  ( ) ;
	DEFINEDLL ~CDLLTestingClass ( ) ;
	DEFINEDLL CString FirstDLLFunction( CString sValue ) ;

};

