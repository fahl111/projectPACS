#include "pch.h"
#include "ISocketOwner.h"

DEFINEDLL void ISocketOwner :: OnSocketConnet ( int nErrorCode )
{
	//Do Nothing here
}

DEFINEDLL void ISocketOwner :: OnSocketAccept ( int nErrorCode )
{
	//Do Nothing here
}

DEFINEDLL void ISocketOwner :: OnSocketClose ( int nErrorCode )
{
	//Do Nothing here
}

DEFINEDLL void ISocketOwner :: OnSocketSend ( int nErrorCode )
{
	//Do Nothing here
}

DEFINEDLL void ISocketOwner :: OnSocketReceive ( int nErrorCode )
{
	//Do Nothing here
}
