#pragma once

#include"ImageDetails.h"
#include <iostream>
#include <vector>

#if defined( BUILD_DLL )
#define DEFINEDLL __declspec(dllexport)
#else
#define DEFINEDLL __declspec(dllimport)
#endif


class CSeriesDetails : public CObject
{
public:

	DECLARE_SERIAL( CSeriesDetails );

	/// Variable to store the Series name
	CString m_sSeriesName = _T("");

	/// Collection variable to store the images details
	std::vector<CImageDetails*> m_vImageDetails;

public:

	//Default Constructor
	DEFINEDLL CSeriesDetails();

	/// Argumented Constructor to create CSeriesDetails object
	DEFINEDLL CSeriesDetails(CString sSeiresName);

	/// Function to add image details to the collection
	DEFINEDLL void AddImage(CImageDetails* pImageDetials);

	DEFINEDLL virtual void Serialize(CArchive& ar);

	/// <summary>
	/// Convert the procedure details to string 
	/// </summary>
	/// <returns></returns>	
	DEFINEDLL CString  ConvertSeriesToString( ) ;

	/// <summary>
	/// Read the data from formated string
	/// </summary>
	/// <param name="sValue"></param>
	/// <returns></returns>
	DEFINEDLL void ReadSeriesFromString ( const CString& sValue ) ;
};

