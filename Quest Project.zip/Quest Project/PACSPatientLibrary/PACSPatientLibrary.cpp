// PACSPatientLibrary.cpp : Defines the initialization routines for the DLL.
//

#include "pch.h"
#include "framework.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


