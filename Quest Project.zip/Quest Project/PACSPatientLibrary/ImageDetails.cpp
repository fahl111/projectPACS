
#include "pch.h"
#include "ImageDetails.h"

IMPLEMENT_SERIAL(CImageDetails, CObject, 1);

DEFINEDLL CImageDetails::CImageDetails()
{
}

// Argumented constructor for CImageDetails object
DEFINEDLL CImageDetails::CImageDetails(CString sImageName, CString sImagePath)
{
	m_sImageName = sImageName;
	m_sImagePath = sImagePath;
}


DEFINEDLL void CImageDetails::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	
		ar << m_sImageName << m_sImagePath;
	}
	else
	{
		ar >> m_sImageName >> m_sImagePath;
	}
}

/// <summary>
/// Convert the patient Image details to a string.
/// </summary>
/// <returns></returns>
DEFINEDLL CString  CImageDetails :: ConvertImageToString ( )
{
	CString sValue = m_sImageName + _T( "," ) + m_sImagePath ;
	return sValue;
}

/// <summary>
/// Read the data from formated string
/// </summary>
/// <param name="sValue"></param>
/// <returns></returns>
DEFINEDLL void CImageDetails::ReadImageFromString(const CString& sValue)
{
	int nTokenPos = 0;
	CString sToken = sValue.Tokenize(_T(","), nTokenPos);
	m_sImageName = sToken ;  //Series Name

	sToken = sValue.Tokenize(_T(","), nTokenPos);
	m_sImagePath = sToken ; 
}