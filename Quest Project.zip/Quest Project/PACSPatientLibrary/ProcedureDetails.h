#pragma once

#if defined( BUILD_DLL )
#define DEFINEDLL __declspec(dllexport)
#else
#define DEFINEDLL __declspec(dllimport)
#endif


#include <iostream>
#include <vector>
#include "SeriesDetails.h"

class CProcedureDetails : public CObject
{

public:

	DECLARE_SERIAL(CProcedureDetails);

	/// Variable to store the procedure name
	CString m_sProcedureName = _T("");

	/// Variable to store the sereis details
	std::vector <CSeriesDetails*> m_vSeriesDetials;

public:

	//Default Constructor
	DEFINEDLL CProcedureDetails();

	/// Argumented constructor to create CProcedureDetials objecdt
	DEFINEDLL CProcedureDetails(CString sProedureNme);

	/// Add series obje to the list
	DEFINEDLL void AddSeriesDetails(CSeriesDetails* pSeriesDetails);

	DEFINEDLL virtual void Serialize(CArchive& ar);

	/// <summary>
	/// Convert the procedure details to string 
	/// </summary>
	/// <returns></returns>
	DEFINEDLL CString  ConvertProcedureToString( ) ;

	/// <summary>
	/// Read the data from formated string
	/// </summary>
	/// <param name="sValue"></param>
	/// <returns></returns>
	DEFINEDLL void ReadProceduresFromString ( const CString& sValue ) ;
} ;

