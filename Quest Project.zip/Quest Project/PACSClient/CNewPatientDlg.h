#pragma once
#include "afxdialogex.h"


// CNewPatientDlg dialog
class CPatientDetails ;
class CNewPatientDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CNewPatientDlg)

public:
	CNewPatientDlg(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CNewPatientDlg();



// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DLG_NEWPATIENT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	/// <summary>
	/// Member variable to store the new Patient Details object
	/// </summary>
	CPatientDetails* m_pPatientDetail = NULL ;

	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnBnClickedOk();

	/// <summary>
	/// Function returs the newly added patient details 
	/// </summary>
	/// <returns></returns>
	CPatientDetails* GetNewPatientDetails( ) ;
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);
	CTreeCtrl m_oPatientDemographicDetails;
	afx_msg void OnTreemanagementAddprocedure();
	afx_msg void OnTreemanagementAddseries();
	afx_msg void OnTreemanagementAddimage();
	afx_msg void OnUpdateTreemanagementAddprocedure(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTreemanagementAddseries(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTreemanagementAddimage(CCmdUI* pCmdUI);
};
