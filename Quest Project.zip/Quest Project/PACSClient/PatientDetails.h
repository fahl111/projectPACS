#pragma once
#include <afx.h>
#include <vector>

class CProcedureDetails ;
class CPatientDetails :     public CObject
{
protected :

	/// <summary>
	/// Variable to store patient Medical Record Number
	/// </summary>
	CString m_sPatientMRN = _T( "" ) ;

	/// <summary>
	/// Collection object to store the procedures for the patient
	/// </summary>
	std::vector<CProcedureDetails*> m_vProcedureDetails ;

public :

	/// <summary>
	/// Argumented constructor for Adding Patient Details
	/// </summary>
	/// <param name="sPatientMRN"></param>
	CPatientDetails( CString sPatientMRN ) ;

	/// <summary>
	/// Returns The Patient Name
	/// </summary>
	/// <returns></returns>
	CString GetPatientMRN( ) ;

	/// <summary>
	/// Functrion to set procedure details for the patient
	/// </summary>
	/// <param name="pProcedureDetails"></param>
	void SetPatientProcedure(CProcedureDetails* pProcedureDetails ) ;

};

