#include "pch.h"
#include "ProcedureDetails.h"

/// <summary>
/// Argumented constructor to save the Procedure Name
/// </summary>
/// <param name="sProcedureName"></param>
CProcedureDetails::CProcedureDetails(CString sProcedureName)
{
	m_sProcedureName = sProcedureName ;
}
