
// PACSClientView.cpp : implementation of the CPACSClientView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "PACSClient.h"
#endif

#include "PACSClientDoc.h"
#include "PACSClientView.h"
#include "CNewPatientDlg.h"
#include "PatientDetails.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPACSClientView

IMPLEMENT_DYNCREATE(CPACSClientView, CFormView)

BEGIN_MESSAGE_MAP(CPACSClientView, CFormView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_BN_CLICKED(IDC_BTN_NEW, &CPACSClientView::OnBnClickedBtnNew)
	ON_NOTIFY(NM_DBLCLK, IDC_PAT_LIST, &CPACSClientView::OnDblclkPatList)
	ON_BN_CLICKED(IDC_BTN_LOADFROMFILE, &CPACSClientView::OnBnClickedBtnLoadfromfile)
END_MESSAGE_MAP()

// CPACSClientView construction/destruction

CPACSClientView::CPACSClientView() noexcept
	: CFormView(IDD_PACSCLIENT_FORM)
{
	// TODO: add construction code here

}

CPACSClientView::~CPACSClientView()
{
}

void CPACSClientView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PAT_LIST, m_oPatientList);
	DDX_Control(pDX, IDC_CMB_GENDER, m_oPatientGender ) ;
	DDX_CBString( pDX, IDC_CMB_GENDER, m_sGenderValue ) ;
}

BOOL CPACSClientView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CPACSClientView :: OnInitialUpdate ( ) //OnInitDialog
{

	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	// CListCtrl - Class to manage the list contro
	m_oPatientList.InsertColumn( 0, _T( "Patient Name" ), 0, 200 ) ;
	m_oPatientList.InsertColumn( 1, _T("Patient MRN"), 0, 200 );


	m_oPatientGender.AddString(_T( "Male" )) ;
	m_oPatientGender.InsertString(0, _T("Female" )) ;

}

void CPACSClientView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CPACSClientView :: OnContextMenu ( CWnd*  pWnd , CPoint point )
{

	//if (*pWnd != m_oPatientList ) return ;

	//CPoint oTreePoint = point;

	//m_oPatientList.ScreenToClient(&oTreePoint);

	//HTREEITEM hItemClicked = m_oPatientList.HitTest(oTreePoint);

	//if (NULL != hItemClicked)
	//	m_oPatientList.SelectItem(hItemClicked);

	//CMenu oMainMenu;
	//oMainMenu.LoadMenuW(IDR_MENU1);
	//CMenu* pSubMenu = oMainMenu.GetSubMenu(0);
	//m_oPatientList.ClientToScreen(&oTreePoint);
	//pSubMenu->TrackPopupMenu(TPM_LEFTALIGN, oTreePoint.x, oTreePoint.y, this);
}


// CPACSClientView diagnostics

#ifdef _DEBUG
void CPACSClientView::AssertValid() const
{
	CFormView::AssertValid();
}

void CPACSClientView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CPACSClientDoc* CPACSClientView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPACSClientDoc)));
	return (CPACSClientDoc*)m_pDocument;
}
#endif //_DEBUG


// CPACSClientView message handlers



void CPACSClientView::OnBnClickedBtnNew()
{
	//Open the New Dialog for creating a new patient entry

	//The new Dilog will return Patient Object 

	//Add the new Patient Name to the List control 

	CNewPatientDlg oNewPatient ;
	if (IDOK == oNewPatient.DoModal())
	{
		CPatientDetails* pPatientDetails = oNewPatient.GetNewPatientDetails();
		m_oPatientList.InsertItem(0, pPatientDetails->GetPatientMRN());

		GetDocument( )/*REturns The active Document OBject*/
			-> GetPatientCollection() [pPatientDetails -> GetPatientMRN()] = pPatientDetails;

		//GetDocument()->m_oSavedPatientDetails[pPatientDetails->GetPatientMRN()] = pPatientDetails ;
		//GetDocument()->m_oSavedPatientDetails[_T("PatientName")] = pPatientDetails;

	//int nItem = m_oPatientList.InsertItem(0, _T("Vinod Sasi"));
	//m_oPatientList.SetItemText(nItem, 1, _T("MRN1000"));

	}
	//LVITEM lVITem;
	//lVITem.
	//m_oPatientList.SetItem (( nItem, 1, LVIF_TEXT,  _T( "MRN1000" )) ;

}


void CPACSClientView :: OnDblclkPatList ( NMHDR* pNMHDR, LRESULT* pResult )
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;


	int nSelectedItem = m_oPatientList.GetSelectionMark();//Get the selected item index
	CString sSelectedMRN = m_oPatientList.GetItemText(nSelectedItem, 0);

	CPatientDetails * pPatientDetails = GetDocument()/*REturns The active Document OBject*/
											-> GetPatientCollection()[sSelectedMRN] ;

	// CPatientDetails * pPatientDetails = GetDocument()->m_oSavedPatientDetails[sSelectedMRN]  ;
	//CPatientDetails * pPatientDetails = GetDocument()->m_oSavedPatientDetails[_T("PatientName")] ;


	//Fill the Controls using pPatientDetails

}


void CPACSClientView :: OnBnClickedBtnLoadfromfile ( )
{
	//Code to iterate through a System Folder and read all the files of specific extention 

	//CSCUProjectDoc* pDocument = reinterpret_cast<CSCUProjectDoc*>  (wParam);
	CPACSClientDoc * pDocument = GetDocument( ) ;

	//CMutex oMutex(FALSE, _T("MutexPatienDetailsObject")); //Create Mutex for Load Thread Synchronization with Main thread 
	//int nWaitResult = WaitForSingleObject(oMutex, INFINITE);//Make sure The Mutex is free 
	//if (nWaitResult >= 0 && oMutex.Lock()) //Get Acccess on the Mutex or Lock Mutex
	{
		WIN32_FIND_DATA oFileData; //Creating the File data object to browse through a folder
		CString sFileToFind = _T("PatientFiles\\*.pat");//I want to get all the files with extension .pat
		CString sFilePathName = _T("");
		CString sFileName = _T("");
		CFile* pFile = NULL;
		CPatientDetails* pPatientDetails = NULL;
		HANDLE oHandle = ::FindFirstFile(sFileToFind, &oFileData);//Find the first file in the Folder with the specified name

		do
		{
			//  C:\MyProjects\PACSClientApp\PatientFiles\*.pat - Absolute path
			if (NULL == oHandle) return;//LRESULT(); //If no files find with the specified extention
			sFileName = oFileData.cFileName;
			sFilePathName = _T("PatientFiles\\") + sFileName; //Get the complete file name - Relative Path 
			pFile = new CFile(); //Create file object
			if (!pFile->Open(sFilePathName, CFile::modeRead)) //Open the file for reading 
			{
				//MessageBox( GetDesktopWindow(), _T("Cannot Open the file ") + sFileName + _T(" For writing."));
				return ;//LRESULT();
			}

			CArchive oArchive(pFile, CArchive::Mode::load);  //Create a Serialize object
			pPatientDetails = NULL;
			pPatientDetails = new CPatientDetails();
			pPatientDetails->Serialize(oArchive);
			pDocument->GetPatientCollection()[
				pPatientDetails->GetPatientMRN()] = pPatientDetails; //Add object to the Map//Patient name is given as key,and Patient object as value

			oArchive.Close();
			pFile->Close();
		} while (FindNextFile(oHandle, &oFileData));
		//oMutex.Unlock();
		return;//LRESULT();
	}
}
