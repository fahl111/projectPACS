#pragma once
#include <afx.h>
class CProcedureDetails : public CObject
{
protected :

	/// <summary>
	/// Variable to store the pocedure details 
	/// </summary>
	CString m_sProcedureName = _T( "" ) ;

	//Vector to collect the series

public :

	/// <summary>
	/// Argumented constructor to save the Procedure Name
	/// </summary>
	/// <param name="sProcedureName"></param>
	CProcedureDetails ( CString sProcedureName ) ;

	//Function to set Series details
};

