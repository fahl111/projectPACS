
// PACSClientDoc.h : interface of the CPACSClientDoc class
//


#pragma once

class CPatientDetails;
class CPACSClientDoc : public CDocument
{
protected: // create from serialization only
	CPACSClientDoc() noexcept;
	DECLARE_DYNCREATE(CPACSClientDoc)

// Attributes
public:

// Operations
public:


// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// Implementation
public:
	virtual ~CPACSClientDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public :

	/// <summary>
	/// Function to return the Collection object
	/// </summary>
	/// <returns></returns>
	CMap<CString, LPCTSTR, CPatientDetails*, CPatientDetails*> & GetPatientCollection( ) ;


protected:
	
	/// <summary>
	/// Variable to store the selected patients
	/// </summary>
	CMap <CString, LPCTSTR, CPatientDetails*, CPatientDetails*> m_oSavedPatientDetails;


// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
};
