#include "pch.h"
#include "PatientDetails.h"
#include "ProcedureDetails.h"

/// <summary>
/// Argumented constructor for Adding Patient Details
/// </summary>
/// <param name="sPatientMRN"></param>
CPatientDetails::CPatientDetails ( CString sPatientMRN )
{
	m_sPatientMRN = sPatientMRN ;
}


/// <summary>
/// Returns The Patient Name
/// </summary>
/// <returns></returns>
CString CPatientDetails::GetPatientMRN()
{
	return m_sPatientMRN;
}

/// <summary>
/// Functrion to set procedure details for the patient
/// </summary>
/// <param name="pProcedureDetails"></param>
void CPatientDetails::SetPatientProcedure( CProcedureDetails * pProcedureDetails ) 
{
	m_vProcedureDetails.push_back ( pProcedureDetails ) ;
}
