// CNewPatientDlg.cpp : implementation file
//

#include "pch.h"
#include "PACSClient.h"
#include "afxdialogex.h"
#include "CNewPatientDlg.h"
#include "PatientDetails.h"
#include "ProcedureDetails.h"


// CNewPatientDlg dialog

IMPLEMENT_DYNAMIC(CNewPatientDlg, CDialogEx)

CNewPatientDlg::CNewPatientDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DLG_NEWPATIENT, pParent)
{

}

CNewPatientDlg::~CNewPatientDlg()
{
}

void CNewPatientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PAT_CLINICAL_DETAILS, m_oPatientDemographicDetails);
}


BEGIN_MESSAGE_MAP(CNewPatientDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CNewPatientDlg::OnBnClickedOk)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_TREEMANAGEMENT_ADDPROCEDURE, &CNewPatientDlg::OnTreemanagementAddprocedure)
	ON_COMMAND(ID_TREEMANAGEMENT_ADDSERIES, &CNewPatientDlg::OnTreemanagementAddseries)
	ON_COMMAND(ID_TREEMANAGEMENT_ADDIMAGE, &CNewPatientDlg::OnTreemanagementAddimage)
	ON_UPDATE_COMMAND_UI(ID_TREEMANAGEMENT_ADDPROCEDURE, &CNewPatientDlg::OnUpdateTreemanagementAddprocedure)
	ON_UPDATE_COMMAND_UI(ID_TREEMANAGEMENT_ADDSERIES, &CNewPatientDlg::OnUpdateTreemanagementAddseries)
	ON_UPDATE_COMMAND_UI(ID_TREEMANAGEMENT_ADDIMAGE, &CNewPatientDlg::OnUpdateTreemanagementAddimage)
END_MESSAGE_MAP()


// CNewPatientDlg message handlers


void CNewPatientDlg::OnBnClickedOk()
{
	CString sPatientMRN = _T("");
	GetDlgItemText(IDC_PAT_MRN, sPatientMRN);
	TCHAR cPatientMRN[20];
	::GetWindowText(GetDlgItem(IDC_PAT_MRN)->m_hWnd, cPatientMRN, 20);

	//TODO Collect the Patent details in Patient Object
	m_pPatientDetail = new CPatientDetails(cPatientMRN); //Collect patient details from the controls 

	//Collect Clinical Details from the Tree 
	HTREEITEM hRootItem = m_oPatientDemographicDetails.GetRootItem ( ) ; //Get top most root item in the list 
	HTREEITEM hSeriesItem ;
	HTREEITEM hImageItem ;

	CProcedureDetails* pProcedureDetails = NULL;
	CSeriesDetails * pSeriesDetails = NULL;
	CImageDetails* pImageDetails = NULL;

	CString sValue = _T("");
	CString* pValue = NULL;
	while ( NULL != hRootItem ) //Looping through the Proceedures
	{
		sValue = m_oPatientDemographicDetails.GetItemText(hRootItem);

		pProcedureDetails = new CProcedureDetails(sValue);

		//Add Procedure object to the patient object
		hSeriesItem = m_oPatientDemographicDetails.GetChildItem(hRootItem);

		while (NULL != hSeriesItem) //Loop through the series 
		{
			sValue = m_oPatientDemographicDetails.GetItemText(hSeriesItem); //Get the series name 

			pSeriesDetails = new CSeriesDetails(sValue);

			pProcedureDetails->AddSeriesDetails(pSeriesDetails);

			hImageItem = m_oPatientDemographicDetails.GetChildItem(hSeriesItem);
			while (NULL != hImageItem) //Loop throuhg the image items
			{
				sValue = m_oClinicalData.GetItemText(hImageItem);
				WPARAM dWord = m_oClinicalData.GetItemData(hImageItem);
				//pValue = (CString*)dWord;
				pImageDetails = new CImageDetails(sValue, sValue);
				pSeriesDetails->AddImage(pImageDetails);

				hImageItem = m_oPatientDemographicDetails.GetNextSiblingItem(hImageItem); //Find if there is any more image items added
			}

			hSeriesItem = m_oPatientDemographicDetails.GetNextSiblingItem(hSeriesItem); //Find if there is any more series items added
		}

		hRootItem = m_oPatientDemographicDetails.GetNextSiblingItem(hRootItem); //Find if there is any more procedure items added
	}
	//Save the patient objectg in a file
	CFile oFile;
	oFile.Open(_T("PatientFiles\\PatientMRN.pat"), CFile::modeCreate | CFile::modeWrite); //file object

	CArchive ar(&oFile, CArchive::Mode::store); // CArchive ovejct and attach to CFile object
	pPatientDetails->Serialize(ar);
	ar.Close();
	oFile.Close();

	MessageBox(_T("Saved Succesfully"), _T("SSCUApplication"), MB_OK | MB_ICONINFORMATION);







	CProcedureDetails *  pProcedureDetails = new CProcedureDetails(_T( "ChestMRI" )) ; //Get Procedure details from the control
	m_pPatientDetail->SetPatientProcedure (pProcedureDetails) ;

	//Get The Patient Details from the controls 
	//Create Patient Class and other clinical details classes 
	//Return the Patient class derails to View class 
	CDialogEx::OnOK();
}

/// <summary>
/// Function returs the newly added patient details 
/// </summary>
/// <returns></returns>
CPatientDetails* CNewPatientDlg::GetNewPatientDetails()
{
	return m_pPatientDetail ;
}


void CNewPatientDlg :: OnContextMenu ( CWnd * pWnd, CPoint point )
{
	if (*pWnd != m_oPatientDemographicDetails) return;

	CPoint oTreePoint = point;

	m_oPatientDemographicDetails.ScreenToClient(&oTreePoint);

	HTREEITEM hItemClicked = m_oPatientDemographicDetails.HitTest(oTreePoint);

	if (NULL != hItemClicked)
		m_oPatientDemographicDetails.SelectItem(hItemClicked);

	CMenu oMainMenu;
	oMainMenu.LoadMenuW(IDR_CONTEXT_MENU);
	CMenu * pSubMenu = oMainMenu.GetSubMenu(0);
	m_oPatientDemographicDetails.ClientToScreen(&oTreePoint);
	pSubMenu->TrackPopupMenu(TPM_LEFTALIGN, oTreePoint.x, oTreePoint.y, this);
}


void CNewPatientDlg::OnTreemanagementAddprocedure()
{
	//Create New Dialog box and get the Procedure name 

	//Add the Procedure name to the Tree control
	HTREEITEM hItem = m_oPatientDemographicDetails.InsertItem(_T( "Procedure Name" )) ;
	m_oPatientDemographicDetails.SetItemData(hItem, 1 /*To Identify Procedures*/);

}


void CNewPatientDlg::OnTreemanagementAddseries()
{
	//Create New Dialog box and get the Serires name 


	HTREEITEM hItem = m_oPatientDemographicDetails.GetSelectedItem();
	hItem = m_oPatientDemographicDetails.InsertItem(_T("Series Name"), hItem);
	m_oPatientDemographicDetails.SetItemData(hItem, 2 /*To Identify Procedures*/);
}


void CNewPatientDlg::OnTreemanagementAddimage()
{

	//Create a CFile Dialog object and get the Image name

	HTREEITEM hItem = m_oPatientDemographicDetails.GetSelectedItem();
	hItem = m_oPatientDemographicDetails.InsertItem(_T("Image Name"), hItem);
	m_oPatientDemographicDetails.SetItemData(hItem, 3 /*To Identify Images*/);
}


void CNewPatientDlg::OnUpdateTreemanagementAddprocedure(CCmdUI* pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CNewPatientDlg::OnUpdateTreemanagementAddseries(CCmdUI* pCmdUI)
{
	HTREEITEM hItem = m_oPatientDemographicDetails.GetSelectedItem();

	if (1/*Procedure*/ != m_oPatientDemographicDetails.GetItemData(hItem)) pCmdUI->Enable(FALSE/*Cannot Execute the Event*/);
}


void CNewPatientDlg::OnUpdateTreemanagementAddimage(CCmdUI* pCmdUI)
{
	HTREEITEM hItem = m_oPatientDemographicDetails.GetSelectedItem();

	if (2/*Serires*/ != m_oPatientDemographicDetails.GetItemData(hItem)) pCmdUI->Enable(FALSE/*Cannot Execute the Event*/);
}
