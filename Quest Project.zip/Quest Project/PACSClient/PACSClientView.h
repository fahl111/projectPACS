
// PACSClientView.h : interface of the CPACSClientView class
//

#pragma once

class CPatientDetails ;
class CPACSClientView : public CFormView
{
protected: // create from serialization only
	CPACSClientView() noexcept;
	DECLARE_DYNCREATE(CPACSClientView)

public:
#ifdef AFX_DESIGN_TIME
	enum{ IDD = IDD_PACSCLIENT_FORM };
#endif

// Attributes
public:
	CPACSClientDoc* GetDocument() const;

// Operations
public:


// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct

// Implementation
public:
	virtual ~CPACSClientView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangePatAddress();
	afx_msg void OnBnClickedBtnNew();
	


	CListCtrl m_oPatientList ;
	CComboBox m_oPatientGender ;
	CString m_sGenderValue = _T( "" ) ; 
	afx_msg void OnDblclkPatList(NMHDR* pNMHDR, LRESULT* pResult);
};

#ifndef _DEBUG  // debug version in PACSClientView.cpp
inline CPACSClientDoc* CPACSClientView::GetDocument() const
   { return reinterpret_cast<CPACSClientDoc*>(m_pDocument); }
#endif

