#include "pch.h"
#include "SeriesDetails.h"


IMPLEMENT_SERIAL(CSeriesDetails, CObject, 1);

DEFINEDLL CSeriesDetails::CSeriesDetails()
{
}

/// Argumented Constructor to create CSeriesDetails object
DEFINEDLL CSeriesDetails::CSeriesDetails(CString sSeiresName)
{
	m_sSeriesName = sSeiresName;
}

/// Function to add image details to the collection
DEFINEDLL void CSeriesDetails::AddImage(CImageDetails* pImageDetials)
{
	m_vImageDetails.push_back(pImageDetials);
}


DEFINEDLL void CSeriesDetails::Serialize(CArchive& ar)
{
	int nCount = 0;
	if (ar.IsStoring())
	{
		ar << m_sSeriesName;
		ar << m_vImageDetails.size();

		CImageDetails * pImageDetails =  NULL;

		for (int i = 0; i < m_vImageDetails.size(); ++i)
		{
			pImageDetails = m_vImageDetails[i];
			pImageDetails -> Serialize( ar ) ;
		}
	}
	else
	{
		ar >> m_sSeriesName;
		ar >> nCount;
		CImageDetails* pImageDetails = NULL;

		m_vImageDetails.clear();

		for (int i = 0; i < nCount; ++i)
		{
			pImageDetails = new CImageDetails( ) ;
			pImageDetails->Serialize(ar) ;
			if (NULL == pImageDetails) --i ;
			else m_vImageDetails.push_back(pImageDetails);
		}
	}
}

/// <summary>
/// Convert the patient series details to a string.
/// </summary>
/// <returns></returns>
DEFINEDLL CString  CSeriesDetails::ConvertSeriesToString()
{
	CString sValue = m_sSeriesName ;
	CImageDetails * pImageDetails = NULL ;
	for (int n = 0; n < m_vImageDetails.size(); ++n)
	{
		pImageDetails = m_vImageDetails[n] ;
		sValue.Format(_T("%s^%s"), sValue, pImageDetails->ConvertImageToString());
	}
	return sValue;
}

/// <summary>
/// Read the data from formated string
/// </summary>
/// <param name="sValue"></param>
/// <returns></returns>
DEFINEDLL void CSeriesDetails::ReadSeriesFromString(const CString& sValue)
{
	int nTokenPos = 0;
	CString sToken = sValue.Tokenize(_T("^"), nTokenPos);
	m_sSeriesName = sToken ;  //Series Name

	CImageDetails * pImageDetails = NULL ;
	sToken = sValue.Tokenize(_T("^"), nTokenPos);
	while (!sToken.IsEmpty())
	{
		pImageDetails = new CImageDetails( ) ;
		pImageDetails -> ReadImageFromString( sToken ) ;
		m_vImageDetails.push_back( pImageDetails ) ;
		sToken = sValue.Tokenize(_T("^"), nTokenPos);
	}
}
