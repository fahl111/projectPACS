#include "pch.h"
#include "PatientDetails.h"

/// Default Constructor 
DEFINEDLL CPatientDetails::CPatientDetails()
{

}

IMPLEMENT_SERIAL(CPatientDetails, CObject, 1);

/// Argumented constructor for patient details class

DEFINEDLL CPatientDetails::CPatientDetails( CString sPatientName, CString sPatientDOB,
				int nPatientAge, CString sPatientMRN, CString sPatientAdd1, CString sPatientAdd2 )
{
	m_sPatientName	= sPatientName;
	m_sDOB			= sPatientDOB ;
	m_nAge			= nPatientAge ;
	m_sPatientMRN	= sPatientMRN ;
	m_sAddress1		= sPatientAdd1;
	m_sAddress2		= sPatientAdd2;

}

/// Function to add procedure detials ot the arrray

DEFINEDLL void CPatientDetails::AddProcedureDetials(CProcedureDetails* pProcedureDetails)
{
	m_vProcedureDetails.push_back(pProcedureDetails);
}


DEFINEDLL void CPatientDetails::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_sPatientName << m_nAge << m_sDOB << m_sAddress1 << m_sAddress2;
		ar << m_vProcedureDetails.size();
		CProcedureDetails* pProcedureDetailis = NULL;
		for (int n = 0; n < m_vProcedureDetails.size(); ++n)
		{
			pProcedureDetailis = m_vProcedureDetails[n];
			pProcedureDetailis -> Serialize ( ar ) ;
		}
	}
	else
	{
		ar >> m_sPatientName >> m_nAge >> m_sDOB >> m_sAddress1 >> m_sAddress2;
		int nCount = 0;
		ar >> nCount;
		CProcedureDetails* pProcedureDetailis = NULL;
		m_vProcedureDetails.clear();
		for (int n = 0; n < nCount; ++n)
		{
			pProcedureDetailis = new CProcedureDetails ( ) ;
			pProcedureDetailis -> Serialize ( ar ) ;
			if (NULL == pProcedureDetailis) --n ;
			else m_vProcedureDetails.push_back(pProcedureDetailis);
		}
	}
}


/// <summary>
/// Convert the patient demographic details to a string.
/// </summary>
/// <returns></returns>
DEFINEDLL CString CPatientDetails::ConvertToString()
{
	 
	CString sValue = _T( "" ) ;
	sValue.Format( _T( "%s;%s;%d;%s;%s;%s" ), m_sPatientName, m_sPatientMRN, m_nAge, m_sDOB, m_sAddress1, m_sAddress2 ) ;
	return sValue ;
}

/// <summary>
/// Read the data from formated string
/// </summary>
/// <param name="sValue"></param>
/// <returns></returns>
DEFINEDLL void CPatientDetails :: ReadFromString(const CString& sValue)
{
	int nTokenPos = 0 ;
	CString sToken = sValue.Tokenize( _T(";"), nTokenPos ) ;
	m_sPatientName = sToken ; 

	sToken = sValue.Tokenize ( _T(";"), nTokenPos ) ;
	m_sPatientMRN = sToken ;

	sToken = sValue.Tokenize(_T(";"), nTokenPos);
	//m_nAge = atoi ( sToken ) ;

	sToken = sValue.Tokenize( _T(";"), nTokenPos ) ;
	m_sDOB = sToken;

	sToken = sValue.Tokenize(_T(";"), nTokenPos);
	m_sAddress1 = sToken;

	sToken = sValue.Tokenize(_T(";"), nTokenPos);
	m_sAddress2 = sToken;

}


/// <summary>
/// Convert the patient procedure details to a string.
/// </summary>
/// <returns></returns>
DEFINEDLL CString  CPatientDetails :: ConvertProcedureToString( )
{
	CString sValue = m_sPatientName ;
	CProcedureDetails* pProcedureDetails = NULL ;
	for ( int n = 0 ; n < m_vProcedureDetails.size ( ) ; ++n)
	{
		pProcedureDetails = m_vProcedureDetails[n] ;
		sValue.Format( _T( "%s|%s" ), sValue, pProcedureDetails -> ConvertProcedureToString( )) ;
	}
	return sValue ;
}

/// <summary>
/// Read the data from formated string
/// </summary>
/// <param name="sValue"></param>
/// <returns></returns>
DEFINEDLL void CPatientDetails :: ReadProceduresFromString ( const CString & sValue)
{
	int nTokenPos = 0 ;
	CString sToken = sValue.Tokenize(_T("|"), nTokenPos);
	sToken ;  //Patient Name

	CProcedureDetails* pProcedureDetails = NULL ;
	sToken = sValue.Tokenize( _T("|"), nTokenPos ) ;
	while ( !sToken.IsEmpty( ))
	{
		pProcedureDetails = new CProcedureDetails( ) ;
		pProcedureDetails->ReadProceduresFromString( sToken ) ;
		m_vProcedureDetails.push_back ( pProcedureDetails ) ;
		sToken = sValue.Tokenize(_T("|"), nTokenPos);
	}
}


