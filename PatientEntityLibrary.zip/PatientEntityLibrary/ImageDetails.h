#pragma once


#if defined( BUILD_DLL )
#define DEFINEDLL __declspec(dllexport)
#else
#define DEFINEDLL __declspec(dllimport)
#endif


class CImageDetails : public CObject
{

public:

	//Store the size of the image file
	int m_nImageSize = 0 ;

	//Buffer to store the image data
	unsigned char* m_pImageBuffer = NULL;

	DECLARE_SERIAL ( CImageDetails ) ;

	/// Variable to store the image name
	CString m_sImageName = _T( "" ) ;

	/// Variable to store the image path
	CString m_sImagePath = _T( "" ) ;

public :
	//Default Constructor
	DEFINEDLL CImageDetails( ) ;

	// Argumented constructor for CImageDetails object
	DEFINEDLL CImageDetails ( CString sImageName, CString sImagePath ) ;

	DEFINEDLL virtual void Serialize ( CArchive & ar ) ;

	/// <summary>
	/// Convert the procedure details to string 
	/// </summary>
	/// <returns></returns>	
	DEFINEDLL CString  ConvertImageToString();

	/// <summary>
	/// Read the data from formated string
	/// </summary>
	/// <param name="sValue"></param>
	/// <returns></returns>
	DEFINEDLL void ReadImageFromString(const CString& sValue);
};

