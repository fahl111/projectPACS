#include "pch.h"
#include"ProcedureDetails.h"


IMPLEMENT_SERIAL(CProcedureDetails, CObject, 1);

DEFINEDLL CProcedureDetails::CProcedureDetails()
{

}

// Argumented constructor to create CProcedureDetials objecdt
DEFINEDLL CProcedureDetails::CProcedureDetails(CString sProedureNme)
{
	m_sProcedureName = sProedureNme;
}


/// Add series object to the list
DEFINEDLL void CProcedureDetails::AddSeriesDetails(CSeriesDetails* pSeriesDetails)
{
	m_vSeriesDetials.push_back(pSeriesDetails);
}


DEFINEDLL void CProcedureDetails::Serialize(CArchive& ar)
{
	int nCount = 0;
	if (ar.IsStoring())
	{
		ar << m_sProcedureName;
		ar << m_vSeriesDetials.size();
		CSeriesDetails* pSeriesDetails = NULL;

		for (int i = 0; i < m_vSeriesDetials.size(); ++i)
		{
			pSeriesDetails = m_vSeriesDetials[i];
			pSeriesDetails->Serialize(ar);
		}
	}
	else
	{
		ar >> m_sProcedureName;
		ar >> nCount;
		CSeriesDetails* pSeriesDetails = NULL;
		m_vSeriesDetials.clear();

		for (int i = 0; i < nCount; ++i)
		{
			pSeriesDetails = new CSeriesDetails();
			pSeriesDetails->Serialize(ar);
			if (NULL == pSeriesDetails) --i;
			else m_vSeriesDetials.push_back(pSeriesDetails);
		}
	}
}

/// <summary>
/// Convert the patient procedure details to a string.
/// </summary>
/// <returns></returns>
DEFINEDLL CString  CProcedureDetails :: ConvertProcedureToString ( )
{
	CString sValue = m_sProcedureName ;
	CSeriesDetails* pSeriesDetails = NULL ;
	for ( int n = 0 ; n < m_vSeriesDetials.size( ) ; ++n )
	{
		pSeriesDetails = m_vSeriesDetials[n] ;
		sValue.Format( _T("%s;%s"), sValue, pSeriesDetails -> ConvertSeriesToString ( )) ;
	}
	return sValue;
}

/// <summary>
/// Read the data from formated string
/// </summary>
/// <param name="sValue"></param>
/// <returns></returns>
DEFINEDLL void CProcedureDetails::ReadProceduresFromString(const CString& sValue)
{
	int nTokenPos = 0;
	CString sToken = sValue.Tokenize(_T(";"), nTokenPos);
	 m_sProcedureName = sToken;  //ProcedureName 

	CSeriesDetails* pSeriesDetails = NULL ;
	sToken = sValue.Tokenize(_T(";"), nTokenPos);
	while ( !sToken.IsEmpty( ))
	{
		pSeriesDetails = new CSeriesDetails( ) ;
		pSeriesDetails->ReadSeriesFromString( sToken ) ;
		m_vSeriesDetials.push_back( pSeriesDetails ) ;
		sToken = sValue.Tokenize(_T(";"), nTokenPos);
	}
}


