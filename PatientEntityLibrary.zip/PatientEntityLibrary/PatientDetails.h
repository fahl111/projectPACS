#pragma once

#if defined( BUILD_DLL )
#define DEFINEDLL __declspec(dllexport)
#else
#define DEFINEDLL __declspec(dllimport)
#endif

#include "ProcedureDetails.h"

template <class Type>
CString ToCString ( Type value )
{
	return std::to_wstring(value).data();
}


class CPatientDetails : public CObject
{
public:

	// Varriable to store the name of the patient 
	CString m_sPatientName = _T("");

	// Varriable to store the date of birth of the patient 
	CString m_sDOB = _T("");

	// Varriable to store the age of the patient 
	int m_nAge = 0;

	// Varriable to store the MRN of the patient 
	CString m_sPatientMRN = _T("");

	// Varriable to store the address 1 of the patient 
	CString m_sAddress1 = _T("");

	// Varriable to store the address 2 of the patient 
	CString m_sAddress2 = _T("");

	// Vector object of data type CProcedures,a collection of pointers
	std::vector<CProcedureDetails*> m_vProcedureDetails;

	DECLARE_SERIAL( CPatientDetails ) ;


	/// Default Constructor 
	DEFINEDLL CPatientDetails();

	/// Argumented constructor for patient details class
	DEFINEDLL CPatientDetails(CString sPatientName, CString sPatientDOB,
		int nPatientAge, CString sPatientMRN, CString sPatientAdd1, CString sPatientAdd2);

	/// Function to add procedure detials to the arrray
	DEFINEDLL void AddProcedureDetials(CProcedureDetails* pProcedureDetails);

	DEFINEDLL virtual void Serialize(CArchive& ar);

	/// <summary>
	/// Convert the patient demographic details to a string.
	/// </summary>
	/// <returns></returns>
	DEFINEDLL CString ConvertToString( ) ;

	/// <summary>
	/// Read the data from formated string
	/// </summary>
	/// <param name="sValue"></param>
	/// <returns></returns>
	DEFINEDLL void ReadFromString( const CString & sValue ) ;


	/// <summary>
	/// Convert the patient procedure details to a string.
	/// </summary>
	/// <returns></returns>
	DEFINEDLL CString ConvertProcedureToString( ) ;

	/// <summary>
	/// Read the data from formated string
	/// </summary>
	/// <param name="sValue"></param>
	/// <returns></returns>
	DEFINEDLL void ReadProceduresFromString ( const CString& sValue ) ;
};

