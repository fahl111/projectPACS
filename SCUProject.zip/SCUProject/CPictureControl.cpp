// CPictureControl.cpp : implementation file
//

#include "pch.h"
#include "CPictureControl.h"


// CPictureControl

IMPLEMENT_DYNAMIC(CPictureControl, CStatic)

CPictureControl::CPictureControl()
{

}

CPictureControl :: ~CPictureControl( )
{
}


BEGIN_MESSAGE_MAP(CPictureControl, CStatic)
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_PAINT()
END_MESSAGE_MAP()


void CPictureControl :: OnPaint ( )
{

	if (m_sImagePath.IsEmpty()) return CStatic::OnPaint();

	CImage oImage ;//MFC Class For Loding Images 
	HRESULT hr = oImage.Load ( m_sImagePath ) ;
	if ( FAILED( hr ))
	{
		return ;
	}

	CPaintDC dc(this); // device context for painting
	CRect rc;
	GetClientRect( &rc ) ;
	
	//::BitBlt(); //API Functions, Load Image in HB
	//::StretchBlt( ) ; 
	oImage.Draw( dc.m_hDC, rc.left, rc.top, oImage.GetWidth( ), oImage.GetHeight( ), 0, 0,
		oImage.GetWidth(), oImage.GetHeight());
}
// CPictureControl message handlers


