// DlgSharePatientDetails.cpp : implementation file
//

#include "pch.h"
#include "SCUProject.h"
#include "DlgSharePatientDetails.h"
#include "afxdialogex.h"
#pragma warning(disable : 4996)


// CDlgSharePatientDetails dialog

IMPLEMENT_DYNAMIC(CDlgSharePatientDetails, CDialogEx)

CDlgSharePatientDetails::CDlgSharePatientDetails(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DLG_SHAREDETAILS, pParent)
{

}

CDlgSharePatientDetails::~CDlgSharePatientDetails()
{
}

void CDlgSharePatientDetails::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSharePatientDetails, CDialogEx)
	ON_BN_CLICKED(IDC_BTN_CONNECTTOSERVER, &CDlgSharePatientDetails::OnBnClickedBtnConnecttoserver)
	ON_BN_CLICKED(IDC_BTN_SENDDEMOGRAPHIC, &CDlgSharePatientDetails::OnBnClickedBtnSenddemographic)
	ON_BN_CLICKED(IDC_BTN_SENDCLINICAL, &CDlgSharePatientDetails::OnBnClickedBtnSendclinical)
	ON_BN_CLICKED(IDC_BTN_SENDIMAGE, &CDlgSharePatientDetails::OnBnClickedBtnSendimage)
END_MESSAGE_MAP()


// CDlgSharePatientDetails message handlers

/// <summary>
/// Pure virtual function in Isocketowner class
/// Do nothing
/// </summary>
void CDlgSharePatientDetails :: RestriectObjectCreation ( )
{
	//TODO Nothing
}

void CDlgSharePatientDetails::OnBnClickedBtnConnecttoserver()
{
	if (NULL != m_pClientSocket)
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;
	}

	//m_pAsyncClientSocket = new CAsyncClientSocket();//TODO
	m_pClientSocket = new CClientSocket( ) ;

	m_pClientSocket -> SetSocketOwner ( this ) ;
	BOOL bSuccess = m_pClientSocket->CreateClientSocket();
	bSuccess = m_pClientSocket->ConnectToServer(20, _T("127.0.0.1"));//Loop back IP//Local host as per situaion

	GetDlgItem(IDC_BTN_CONNECTTOSERVER)->EnableWindow(FALSE);

	GetDlgItem(IDC_BTN_SENDDEMOGRAPHIC)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_SENDCLINICAL)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_SENDIMAGE)->EnableWindow(TRUE);
	//Dissable this button after connect
	//Ennable, Send Demographic, Send Clinical, And Send Image button after connection established
}


void CDlgSharePatientDetails::OnBnClickedBtnSenddemographic()
{
	//Check if connection to server is established
	CString sMessageHeader = _T( "" ) ;//Char buffer:Demographic data
	CString sTextToSend = m_pSelectedPatient -> ConvertToString ( ) ;
	sMessageHeader.Format( _T("1:1:%d"), sTextToSend.GetLength( )) ;
	m_pClientSocket -> SendData ( sMessageHeader ) ;
	Sleep(10000); //Wait for the header to read//This is not a good method infact, we have to go for Events, or ThreadSycronization,
	//	ArchiveDemographicDetails(); //Data Part send to server
	m_pClientSocket->SendData(sTextToSend);
	Sleep(10000); //Not needed but added here as there is some exceptions, which is to be find out and cleard
	//If yes send demographic information to the server
}


void CDlgSharePatientDetails :: OnBnClickedBtnSendclinical ( )
{
	//Check if connection to server is established
	CString sMessageHeader = _T("");//Char buffer:Demographic data
	CString sTextToSend = m_pSelectedPatient -> ConvertProcedureToString( ) ;

	//m_pPatientDetails->ReadProceduresFromString( sTextToSend ) ; //Just to verify

	sMessageHeader.Format(_T("1:2:%d"), sTextToSend.GetLength());//Char buffer:Clinical details:buffer size
	m_pClientSocket->SendData(sMessageHeader);
	Sleep(10000); //Wait for the header to read//This is not a good method infact, we have to go for Events, or ThreadSycronization,
	m_pClientSocket->SendData(sTextToSend);
	Sleep(10000); //Not needed but added here as there is some exceptions, which is to be find out and cleard
	//If yes send clinical information to the server
}


void CDlgSharePatientDetails :: OnBnClickedBtnSendimage ( )
{
	//Check if connection to server is established
	/*Read file in to memmory buffer */
	long  len ;
	unsigned char * buf = NULL ;
	FILE* fp = NULL ;

	// Open the source file
	CString sPath =
		m_pSelectedPatient -> m_vProcedureDetails[0]->m_vSeriesDetials[0]->m_vImageDetails[0]->m_sImagePath;//Provide option to select one image
	int nCount = sPath.GetLength (  ) ;
	char* strFileName = new char ( nCount ) ;
	strcpy(strFileName, CStringA ( sPath ).GetString( )) ;
	fp = fopen( strFileName, "rb" ) ;
	if ( !fp ) return ;

	// Get its length (in bytes)
	if (fseek(fp, 0, SEEK_END) != 0)   //Move to the end of the, get the file size
	{
		fclose(fp);
		return;
	}

	len = ftell(fp);//Getting the size, or file pointer location
	rewind(fp); //MOve the file pointer to the start of the

	// Get a buffer big enough to hold it entirely
	buf = (unsigned char*)malloc(len);
	if (!buf)
	{
		fclose(fp);
		return;
	}

	// Read the entire file into the buffer
	if (!fread(buf, len, 1, fp))
	{
		free(buf);
		fclose(fp);
		return;
	}

	fclose(fp);
	/* End the read here*/

	CString sMessageHeader = _T("");//Char buffer:Image data
	sMessageHeader.Format(_T("1:3:%d"), len);//Chart buffer:image data:lenght of buffer
	m_pClientSocket->SendData(sMessageHeader);
	Sleep(10000);//Wait for the header to read//This is not a good method infact, we have to go for Events, or ThreadSycronization,
	m_pClientSocket->Send(buf, len); //Direct Send method to send unsigned char *
	Sleep(10000); //Not needed but added here as there is some exceptions, which is to be find out and cleard
	//release buf;
	//If yes send image information to the server
}

void CDlgSharePatientDetails :: OnBnClickedBtnSendimage ( )
{
	//Check if connection to server is established
	/*Read file in to memmory buffer */
	long  len ;
	unsigned char * buf = NULL ;
	FILE* fp = NULL ;

	// Open the source file
	CString sPath =
		m_pSelectedPatient -> m_vProcedureDetails[0]->m_vSeriesDetials[0]->m_vImageDetails[0]->m_sImagePath;//Provide option to select one image
	int nCount = sPath.GetLength (  ) ;
	char* strFileName = new char ( nCount ) ;
	strcpy(strFileName, CStringA ( sPath ).GetString( )) ;
	fp = fopen( strFileName, "rb" ) ;
	if ( !fp ) return ;

	// Get its length (in bytes)
	if (fseek(fp, 0, SEEK_END) != 0)   //Move to the end of the, get the file size
	{
		fclose(fp);
		return;
	}

	len = ftell(fp);//Getting the size, or file pointer location
	rewind(fp); //MOve the file pointer to the start of the

	// Get a buffer big enough to hold it entirely
	buf = (unsigned char*)malloc(len);
	if (!buf)
	{
		fclose(fp);
		return;
	}

	// Read the entire file into the buffer
	if (!fread(buf, len, 1, fp))
	{
		free(buf);
		fclose(fp);
		return;
	}

	fclose(fp);
	/* End the read here*/

	CString sMessageHeader = _T("");//Char buffer:Image data
	sMessageHeader.Format(_T("1:3:%d"), len);//Chart buffer:image data:lenght of buffer
	m_pClientSocket->SendData(sMessageHeader);
	Sleep(10000);//Wait for the header to read//This is not a good method infact, we have to go for Events, or ThreadSycronization,
	m_pClientSocket->Send(buf, len); //Direct Send method to send unsigned char *
	Sleep(10000); //Not needed but added here as there is some exceptions, which is to be find out and cleard
	//release buf;
	//If yes send image information to the server
}