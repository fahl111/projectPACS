
// SCUProjectView.cpp : implementation of the CSCUProjectView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "SCUProject.h"
#endif

#include "SCUProjectDoc.h"
#include "SCUProjectView.h"
#include "DlgSharePatientDetails.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSCUProjectView

IMPLEMENT_DYNCREATE(CSCUProjectView, CFormView)

BEGIN_MESSAGE_MAP(CSCUProjectView, CFormView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_BN_CLICKED(IDC_BTN_NEW, &CSCUProjectView::OnBnClickedBtnNew)
	ON_BN_CLICKED(IDC_BTN_CANCEL, &CSCUProjectView::OnBnClickedBtnCancel)
	ON_BN_CLICKED(IDC_BTN_SAVE, &CSCUProjectView::OnBnClickedBtnSave)
	ON_BN_CLICKED(IDC_BTN_SHARE, &CSCUProjectView::OnBnClickedBtnShare)
	ON_NOTIFY(NM_DBLCLK, IDC_LST_SAVEDPATIENTS, &CSCUProjectView::OnNMDblclkLstSavedpatients)
	ON_BN_CLICKED(IDC_BTN_LOADFROMFILE, &CSCUProjectView::OnBnClickedBtnLoadfromfile)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TRE_CLINICALDETAILS, &CSCUProjectView::OnSelchangedTreClinicaldetails)
	ON_COMMAND(ID_TREEVIEW_ADDPROCEDURE, &CSCUProjectView::OnTreeviewAddprocedure)
	ON_COMMAND(ID_TREEVIEW_ADDSERIES, &CSCUProjectView::OnTreeviewAddseries)
	ON_COMMAND(ID_TREEVIEW_ADDIMAGE, &CSCUProjectView::OnTreeviewAddimage)
	ON_UPDATE_COMMAND_UI(ID_TREEVIEW_ADDPROCEDURE, &CSCUProjectView::OnUpdateTreeviewAddprocedure)
	ON_UPDATE_COMMAND_UI(ID_TREEVIEW_ADDSERIES, &CSCUProjectView::OnUpdateTreeviewAddseries)
	ON_UPDATE_COMMAND_UI(ID_TREEVIEW_ADDIMAGE, &CSCUProjectView::OnUpdateTreeviewAddimage)
END_MESSAGE_MAP()

// CSCUProjectView construction/destruction

CSCUProjectView::CSCUProjectView() noexcept
	: CFormView(IDD_SCUPROJECT_FORM)
{
	// TODO: add construction code here

}

CSCUProjectView::~CSCUProjectView()
{
}

void CSCUProjectView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LST_SAVEDPATIENTS, m_oPatientList);
	DDX_Control(pDX, IDC_TRE_CLINICALDETAILS, m_oClinicalData);
	DDX_Control(pDX, IDC_STATIC_IMAGEBOX, m_oImageBox);
}

BOOL CSCUProjectView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CSCUProjectView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

void CSCUProjectView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CSCUProjectView::OnContextMenu(CWnd *  pWnd , CPoint point)
{
	/*TODO Code added*/
	if (*pWnd != m_oClinicalData) return;

	CPoint oTreePoint = point;

	m_oClinicalData.ScreenToClient(&oTreePoint);

	HTREEITEM hItemClicked = m_oClinicalData.HitTest(oTreePoint);

	if (NULL != hItemClicked)
		m_oClinicalData.SelectItem(hItemClicked);

	CMenu oMainMenu;
	oMainMenu.LoadMenuW(IDR_MENU1);
	CMenu* pSubMenu = oMainMenu.GetSubMenu(0);
	m_oClinicalData.ClientToScreen(&oTreePoint);
	pSubMenu->TrackPopupMenu(TPM_LEFTALIGN, oTreePoint.x, oTreePoint.y, this);
}


// CSCUProjectView diagnostics

#ifdef _DEBUG
/// <summary>
/// Thread function declaration.
/// </summary>
/// <param name="wParam"></param>
/// <returns></returns>
UINT LoadFromFileThread ( LPVOID wParam ) ;

void CSCUProjectView::AssertValid() const
{
	CFormView::AssertValid();
}

void CSCUProjectView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CSCUProjectDoc* CSCUProjectView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSCUProjectDoc)));
	return (CSCUProjectDoc*)m_pDocument;
}
#endif //_DEBUG


// CSCUProjectView message handlers


void CSCUProjectView :: OnBnClickedBtnNew  ( ) 
{
	//TODO Cleare all the controls here 
	//Clear the saved patient object if any 
	//Dissable the New Button 
	//Ennable the Cancel button & Save Button
}


void CSCUProjectView :: OnBnClickedBtnCancel ( )
{
	//TODO Clear all the controls 
	//Clear the saved/selected pateint object if any
	//Enable new button
	//Disable cancel, save and share button 
}

void CSCUProjectView :: OnBnClickedBtnSave ( )
{
	//TODO Collect the Patent details in Patient Object
	CPatientDetails * pPatientDetails = //Collect the contents from the controls 
		new CPatientDetails(_T("Vinod Sasi"), _T("2/2/78"), 43, _T("MN443"), _T("Adress1"), _T("Adress2"));

	//Store the content in a file 
	HTREEITEM hRootItem = m_oClinicalData.GetRootItem(); //Get root item in the list 
	HTREEITEM hSeriesItem;
	HTREEITEM hImageItem;

	CProcedureDetails* pProcedureDetails = NULL;
	CSeriesDetails* pSeriesDetails = NULL;
	CImageDetails* pImageDetails = NULL;

	CString sValue = _T("");
	CString* pValue = NULL;
	while (NULL != hRootItem) //Looping through the Proceedures
	{
		sValue = m_oClinicalData.GetItemText(hRootItem);

		pProcedureDetails = new CProcedureDetails(sValue);

		//Add Procedure object to the patient object
		hSeriesItem = m_oClinicalData.GetChildItem(hRootItem);

		while (NULL != hSeriesItem) //Loop through the series 
		{
			sValue = m_oClinicalData.GetItemText(hSeriesItem); //Get the series name 

			pSeriesDetails = new CSeriesDetails(sValue);

			pProcedureDetails->AddSeriesDetails(pSeriesDetails);

			hImageItem = m_oClinicalData.GetChildItem(hSeriesItem);
			while (NULL != hImageItem) //Loop throuhg the image items
			{
				sValue = m_oClinicalData.GetItemText(hImageItem);
				WPARAM dWord = m_oClinicalData.GetItemData(hImageItem);
				//pValue = (CString*)dWord;
				pImageDetails = new CImageDetails(sValue, sValue);
				pSeriesDetails->AddImage(pImageDetails);

				hImageItem = m_oClinicalData.GetNextSiblingItem(hImageItem); //Find if there is any more image items added
			}

			hSeriesItem = m_oClinicalData.GetNextSiblingItem(hSeriesItem); //Find if there is any more series items added
		}

		hRootItem = m_oClinicalData.GetNextSiblingItem(hRootItem); //Find if there is any more procedure items added
	}
	//Save the patient objectg in a file
	CFile oFile ;
	oFile.Open( _T( "PatientFiles\\PatientMRN.pat"), CFile::modeCreate | CFile::modeWrite ) ; //file object

	CArchive ar( &oFile, CArchive::Mode::store ) ; // CArchive ovejct and attach to CFile object
	pPatientDetails -> Serialize ( ar ) ;
	ar.Close( ) ;
	oFile.Close( ) ;

	MessageBox(_T("Saved Succesfully"), _T("SSCUApplication"), MB_OK | MB_ICONINFORMATION);

	//Add the patient details to the List control on the left 
	//Ennable New Button 
	//Dissable cancel button 
	//Ennable share button 
}

void CSCUProjectView :: OnBnClickedBtnShare ( )
{
	//For Testing 
	m_pSelectedPatient = 
		new CPatientDetails( _T("Vinod Sasi"), _T("2278"), 43, _T("IND3533"), _T("Address 1"), _T("Address 2" )) ;

	if (NULL == m_pSelectedPatient)
	{
		MessageBox(_T("Select A patient to send the details to server"), _T("PACS SCU Application"), MB_ICONWARNING | MB_OK);
		return;
	}

	CDlgSharePatientDetails oSharePatientDetails ;
	oSharePatientDetails.m_pSelectedPatient = m_pSelectedPatient ;

	oSharePatientDetails.DoModal( ) ;

}


void CSCUProjectView::OnNMDblclkLstSavedpatients( NMHDR* pNMHDR, LRESULT* pResult )
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>( pNMHDR ) ;
	int nSelectedItem = m_oPatientList.GetSelectionMark();//Get the selected item index
	CString sSeletedItem = m_oPatientList.GetItemText(nSelectedItem, 0);

	//Get the selected patient from the list and store that in the varialbe in View 
	m_pSelectedPatient = GetDocument( ) -> m_oSavedPatientDetails[sSeletedItem];


	//returns -1 if not selected;
	//m_oPatientList.GetSelectedItem
	//Get the selected patient object and load the patient details in the Controls on Right
	//Ennable New button,
	//Dissable cancel button 
	//Enable share button
	//Disable save button 

	*pResult = 0 ;
}

void CSCUProjectView :: OnBnClickedBtnLoadfromfile ( )
{
	//API to create a thread and start executing the Thread Function
	AfxBeginThread ( LoadFromFileThread, GetDocument( )/*Send Document Object Pointer to the worker thread*/) ;

	Sleep ( 2000 ) ; //To make sure the Worker thread get access to the Synchronization Mutex obejct, its not a must
	CMutex oMutex(FALSE, _T("MutexPatienDetailsObject"));//Create mutext which out ownership 
	if ( WaitForSingleObject(oMutex, INFINITE) >= 0)//Wait till the Mutex is released by the Worker Thread, WaitForMultipleObject() for waiting on multiple synchronization object
	{
		CString	sPatientName = _T("");
		CPatientDetails* pPatientDetails = NULL;

		POSITION pos = GetDocument( ) -> m_oSavedPatientDetails.GetStartPosition ( ) ;
		int nCount = 0 ;
		while ( NULL != pos )
		{
			GetDocument ( ) -> m_oSavedPatientDetails.GetNextAssoc ( pos, sPatientName, pPatientDetails ) ;
			m_oPatientList.InsertItem ( nCount++, sPatientName ) ;
		}
	}

	//Load Already Saved files from the saved folder
	//Insert the patient name from the file in the list 
}

UINT LoadFromFileThread ( LPVOID wParam )//Newly created thread 
{
	CSCUProjectDoc* pDocument = reinterpret_cast<CSCUProjectDoc*>  ( wParam ) ;
	CMutex oMutex ( FALSE, _T( "MutexPatienDetailsObject" )) ; //Create Mutex for Load Thread Synchronization with Main thread 
	int nWaitResult = WaitForSingleObject ( oMutex, INFINITE ) ;//Make sure The Mutex is free 
	if ( nWaitResult >= 0 && oMutex.Lock( )) //Get Acccess on the Mutex or Lock Mutex
	{
		WIN32_FIND_DATA oFileData; //Creating the File data object to browse through a folder
		CString sFileToFind = _T("PatientFiles\\*.pat");//I want to get all the files with extension .pat
		CString sFilePathName = _T("");
		CString sFileName = _T("");
		CFile* pFile = NULL;
		CPatientDetails* pPatientDetails = NULL;
		HANDLE oHandle = FindFirstFile(sFileToFind, &oFileData);//Find the first file in the Folder with the specified name

		do
		{
			if (NULL == oHandle) return LRESULT();
			sFileName = oFileData.cFileName;
			sFilePathName = _T("PatientFiles\\") + sFileName;
			pFile = new CFile(); //Create file object
			if ( !pFile -> Open ( sFilePathName, CFile::modeRead )) //Open the file for reading 
			{
				//MessageBox( GetDesktopWindow(), _T("Cannot Open the file ") + sFileName + _T(" For writing."));
				return LRESULT();
			}

			CArchive oArchive(pFile, CArchive::Mode::load);  //Create a Serialize object
			pPatientDetails = NULL;
			pPatientDetails = new CPatientDetails();
			pPatientDetails->Serialize(oArchive);
			pDocument -> m_oSavedPatientDetails[
				pPatientDetails->m_sPatientName] = pPatientDetails; //Add object to the Map//Patient name is given as key,and Patient object as value

			oArchive.Close();
			pFile->Close();
		} while (FindNextFile(oHandle, &oFileData));
		oMutex.Unlock();
		return LRESULT();
	}
	return 0 ;
}


void CSCUProjectView :: OnSelchangedTreClinicaldetails ( NMHDR* pNMHDR, LRESULT* pResult )
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR) ;

	HTREEITEM hItem = m_oClinicalData.GetSelectedItem( ) ;

	if ( 3/*Image Path*/ != m_oClinicalData.GetItemData( hItem )) return ;

	CString sValue = m_oClinicalData.GetItemText( hItem ) ;

	m_oImageBox.m_sImagePath = _T( "C:\\Users\\Vinod Sasi\\Desktop\\RISE.png" ) ;

	*pResult = 0;
}


void CSCUProjectView::OnTreeviewAddprocedure()
{
	HTREEITEM hItem = m_oClinicalData.InsertItem(_T( "Procedure Name" )); 
	m_oClinicalData.SetItemData ( hItem, 1 /*To Identify Procedures*/ ) ;
}


void CSCUProjectView::OnTreeviewAddseries()
{
	HTREEITEM hItem = m_oClinicalData.GetSelectedItem( ) ;
	hItem = m_oClinicalData.InsertItem(_T("Series Name"), hItem ) ;
	m_oClinicalData.SetItemData ( hItem, 2 /*To Identify Procedures*/);
}


void CSCUProjectView::OnTreeviewAddimage()
{
	HTREEITEM hItem = m_oClinicalData.GetSelectedItem();
	hItem = m_oClinicalData.InsertItem(_T("Image Name"), hItem);
	m_oClinicalData.SetItemData ( hItem, 3 /*To Identify Procedures*/ ) ;
}


void CSCUProjectView :: OnUpdateTreeviewAddprocedure ( CCmdUI * pCmdUI )
{
	//I dont have to check here as Add Procedure adds a procedure to the root
}


void CSCUProjectView :: OnUpdateTreeviewAddseries ( CCmdUI * pCmdUI )
{
	HTREEITEM hItem = m_oClinicalData.GetSelectedItem( ) ;

	if ( 1/*Procedure*/ != m_oClinicalData.GetItemData( hItem )) pCmdUI -> Enable( FALSE/*Cannot Execute the Event*/);
}


void CSCUProjectView :: OnUpdateTreeviewAddimage ( CCmdUI* pCmdUI )
{
	HTREEITEM hItem = m_oClinicalData.GetSelectedItem();

	if ( 2/*Procedure*/ != m_oClinicalData.GetItemData(hItem)) pCmdUI->Enable(FALSE/*Cannot Execute the Event*/);
}
