#pragma once


// CPictureControl

class CPictureControl : public CStatic
{
	DECLARE_DYNAMIC(CPictureControl)

public:
	CPictureControl();
	virtual ~CPictureControl();
	void OnPaint (  ) ;
	CString m_sImagePath = _T("");
protected:
	DECLARE_MESSAGE_MAP()

};


