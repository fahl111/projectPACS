
// SCUProjectView.h : interface of the CSCUProjectView class
//

#pragma once
#include "PatientDetails.h"
#include "CPictureControl.h"

class CSCUProjectView : public CFormView
{
protected: // create from serialization only
	CSCUProjectView() noexcept;
	DECLARE_DYNCREATE(CSCUProjectView)

	/// <summary>
	/// Variable to store the selected patient details 
	/// </summary>
	CPatientDetails* m_pSelectedPatient = NULL ;

public:
#ifdef AFX_DESIGN_TIME
	enum{ IDD = IDD_SCUPROJECT_FORM };
#endif

// Attributes
public:
	CSCUProjectDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct

// Implementation
public:
	virtual ~CSCUProjectView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnNew();
	afx_msg void OnBnClickedBtnCancel();
	afx_msg void OnBnClickedBtnSave();
	afx_msg void OnBnClickedBtnShare();
	afx_msg void OnNMDblclkLstSavedpatients(NMHDR* pNMHDR, LRESULT* pResult);
	CListCtrl m_oPatientList;
	CTreeCtrl m_oClinicalData;
	afx_msg void OnBnClickedBtnLoadfromfile();

	CPictureControl m_oImageBox;
	afx_msg void OnSelchangedTreClinicaldetails(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeviewAddprocedure();
	afx_msg void OnTreeviewAddseries();
	afx_msg void OnTreeviewAddimage();
	afx_msg void OnUpdateTreeviewAddprocedure(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTreeviewAddseries(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTreeviewAddimage(CCmdUI* pCmdUI);
};

#ifndef _DEBUG  // debug version in SCUProjectView.cpp
inline CSCUProjectDoc* CSCUProjectView::GetDocument() const
   { return reinterpret_cast<CSCUProjectDoc*>(m_pDocument); }
#endif

