#pragma once
#include "PatientDetails.h"
#include "ClientSocket.h"
#include "ISocketOwner.h"

// CDlgSharePatientDetails dialog

class CDlgSharePatientDetails : public CDialogEx, ISocketOwner
{
	DECLARE_DYNAMIC ( CDlgSharePatientDetails )

public:
	CDlgSharePatientDetails(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CDlgSharePatientDetails();
	CPatientDetails* m_pSelectedPatient = NULL ;


// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DLG_SHAREDETAILS };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	/// <summary>
	/// Client socket object to communicate with the server
	/// </summary>
	CClientSocket* m_pClientSocket = NULL ;

	/// <summary>
	/// Pure virtual function in Isocketowner class
	/// Do nothing 
	/// </summary>
	void RestriectObjectCreation ( ) ;

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnConnecttoserver();
	afx_msg void OnBnClickedBtnSenddemographic();
	afx_msg void OnBnClickedBtnSendclinical();
	afx_msg void OnBnClickedBtnSendimage();
};
