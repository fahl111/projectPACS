#pragma once

#include "ISocketOwner.h"
#include "ClientSocket.h"
#include "ServerSocket.h"


// CClientSocketThread

class CClientSocketThread : public CWinThread, ISocketOwner
{
	DECLARE_DYNCREATE(CClientSocketThread)
	
	CClientSocketThread( ) ;
protected:
    
	//Header Format - SendMode{1 : char buffer, 2 : Socket Arichieve } : Message Type{1 : Demographic, 2 : Clinical, 3 : Image }  : size in bytes ; ex "1:1:200"
	BOOL m_bHeaderRecieved = FALSE ; 
	int m_nMessageType = 0 ;
	int m_nMessageMode = 0 ;
	int m_nMessageSize = 0 ;
	
	BOOL LoadImageFromClient( CString & sImagePath ) ;

	virtual ~CClientSocketThread( ) ;	

	static int s_nThreadNumber ;

	CString m_sThreadName = _T( "" ) ;

	void ReceiveSerializedData ( ) ;

	afx_msg void OnExitThread ( WPARAM wParam, LPARAM lParam ) ;

public:
	virtual BOOL InitInstance( ) ;

	virtual int ExitInstance( ) ; 

	//CAsyncClientSocket* m_pClientSocket = NULL ;//TODO
	CClientSocket * m_pClientSocket = NULL ;

	virtual void OnSocketConnet ( int nErrorCode ) ;

	virtual void OnSocketReceive  (int nErrorCode ) ;

	virtual void OnSocketClose ( int nErrorCode ) ;

	virtual void OnSocketSend ( int nErrorCode ) ;

	virtual void RestriectObjectCreation( ) ;

protected:
	DECLARE_MESSAGE_MAP()
};


