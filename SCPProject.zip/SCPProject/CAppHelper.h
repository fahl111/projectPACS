
//This is a helper class, defined as singleton class.
//This store all the main objects or windows handles, so that it will be easy for the communication between different classes
//Also this class stores the shared patient data. So that the data can be accessed from other objects easity
#pragma once

class CSCPProjectView ;
class CSCPProjectDoc ;
class CMainFrame ;
class CSCPProjectApp ;
class CPatientDetails ;

class CAppHelper
{

public :
	
	/// <summary>
	/// The single object of the class
	/// </summary>
	static CAppHelper * s_oAppHelper ;

	/// <summary>
	/// Stores the active application object
	/// </summary>
	CSCPProjectApp * m_pApplication = NULL ;

	/// <summary>
	/// Stores the active Document object
	/// </summary>
	CSCPProjectDoc* m_pDocument = NULL ;

	/// <summary>
	/// Sotores the active main frame object
	/// </summary>
	CMainFrame * m_pFrame = NULL ; 

	/// <summary>
	/// Stores the active View Object
	/// </summary>
	CSCPProjectView * m_pView = NULL ;

	/// <summary>
	/// Variable to store the selected patient
	/// </summary>
	CPatientDetails* m_pSelectedPatient = NULL ;


	/// Stores the Loaded Patient details objects
	/// </summary>
	CMap <CString, LPCTSTR, CWinThread*, CWinThread*> m_oActiveClientThreads;

	/// <summary>
	/// Stores the Loaded Patient details objects
	/// </summary>
	CMap <CString, LPCTSTR, CPatientDetails*, CPatientDetails*> m_oPatientCollection ;

private :

	///// <summary>
	///// This is used to synchronize the object creation
	///// </summary>
	static CCriticalSection s_oCriticalSection ;

	/// <summary>
	/// This function will create the singleton object
	/// </summary>
	static CAppHelper * CreateAppHelper( ) ;

	/// <summary>
	/// Private default constructor 
	/// </summary>
	CAppHelper( ) ;
} ;
