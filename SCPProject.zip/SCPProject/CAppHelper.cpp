#include "pch.h"
#include "CAppHelper.h"
#include "SCPProjectDoc.h"
#include "MainFrm.h"
#include "SCPProjectView.h"
#include "SCPProject.h"
#include "PatientDetails.h"

CCriticalSection CAppHelper::s_oCriticalSection;
CAppHelper* CAppHelper::s_oAppHelper = CAppHelper::CreateAppHelper( ) ;


/// <summary>
/// This function will create the singleton object
/// </summary>
CAppHelper * CAppHelper :: CreateAppHelper( )//This is how we make a singleton object thread safe in multithreaded enviornment
{
	//This is just an explanation of how singleton object is created on a thread safe method
	if ( NULL == s_oAppHelper )//Check if  we need to create an object
	{//Move on to create the objecgt
		s_oCriticalSection.Lock( ) ; //Locking the resource from accessed by multiple threads
		if ( NULL == s_oAppHelper ) 
						s_oAppHelper = new CAppHelper( ) ;
		s_oCriticalSection.Unlock( ) ;
	}
	return s_oAppHelper ; 
}

CAppHelper :: CAppHelper( )
{
}


