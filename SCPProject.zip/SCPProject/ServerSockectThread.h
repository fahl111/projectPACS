#pragma once
#include "ISocketOwner.h"
#include "ServerSocket.h"

// CServerSockectThread
class CServerSockectThread : public CWinThread, ISocketOwner//Becouse this is going to act as the owner of ServerSocket
{
	DECLARE_DYNCREATE ( CServerSockectThread )
	CServerSockectThread ( ) ;           

	CServerSockectThread ( CWnd * pParentWnd ) ;

public : //ISocketOwner Virutal functions implementation
	virtual void OnSocketConnet( int nErrorCode ) ;

	virtual void OnSocketAccept( int nErrorCode ) ;

	virtual void OnSocketClose ( int nErrorCode ) ;

	virtual void RestriectObjectCreation();

protected:
	virtual ~CServerSockectThread ( ) ;

	afx_msg void OnExitServerThred ( WPARAM wParam, LPARAM lParam ) ;

	//CAsyncServerSocket* m_pServerSocket = NULL ;//TODO
	CServerSocket * m_pServerSocket = NULL ;

	CWnd* m_pParentWindow = NULL ;

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
};


