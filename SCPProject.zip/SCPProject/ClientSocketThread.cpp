// ClientSocketThread.cpp : implementation file
//

#include "pch.h"
#include "SCPProject.h"
#include "ClientSocketThread.h"
#include "CAppHelper.h"
#include "PatientDetails.h"
//#include "FileView.h"

//#include "Message.h"

#pragma warning(disable : 4996)

int CClientSocketThread::s_nThreadNumber = 0 ;

// CClientSocketThread

IMPLEMENT_DYNCREATE(CClientSocketThread, CWinThread)

CClientSocketThread::CClientSocketThread()
{
}

CClientSocketThread :: ~CClientSocketThread ( )
{
}

void CClientSocketThread :: OnSocketConnet ( int nErrorCode )
{
}

void CClientSocketThread :: OnSocketReceive ( int nErrorCode )
{
	if (!m_bHeaderRecieved)
	{
		CString sMessageHeader = _T( "" ) ;
		m_pClientSocket->ReceiveData (sMessageHeader) ;
		
		if (sMessageHeader.IsEmpty()) return ;
		//in ASCII code, the numbers(digits) start from 48. All you need to do is:
		
		m_nMessageMode =  (int)sMessageHeader[0] - 48 ;
		m_nMessageType =  (int)sMessageHeader[2] - 48 ;
		m_nMessageSize = _ttoi( sMessageHeader.Mid( 4 )) ;
		//m_pClientSocket -> SendData(_T( "Header Received" ));
		m_bHeaderRecieved = TRUE ;
		return ;
	}

	CString sImagePage = _T("");
	//if (m_pClientSocket->IsKindOf(RUNTIME_CLASS(CClientSocket)))
	CString sDataToReceive;
	switch ( m_nMessageMode )
	{
	case 1 : //Char array
		switch ( m_nMessageType )
		{
		case 1: //Demographic details
		{
			m_pClientSocket->ReceiveData(sDataToReceive);
			CPatientDetails* pPatientDetails = new CPatientDetails();
			pPatientDetails->ReadFromString(sDataToReceive);
			//CAppHelper::s_oAppHelper->m_oPatientCollection[
			//	pPatientDetails->m_sPatientName] = pPatientDetails; //Add object to the Map//Patient name is given as key,and Patient object as value
			//CFileView* pFileView = CAppHelper::s_oAppHelper->m_pFileView;
			//::SendMessage(pFileView->m_hWnd, WM_LOADPATIENTDATA, WPARAM(&pPatientDetails->m_sPatientName), NULL);
			break;
		}
		case 2: //Clinical Details
		{
			m_pClientSocket->ReceiveData(sDataToReceive);
			CString	sPatientName = _T("");
			CPatientDetails* pPatientDetails = NULL;

			int nTokenPos = 0;
			CString sToken = sDataToReceive.Tokenize(_T("|"), nTokenPos);
			sToken;  //Patient Name

			POSITION pos = CAppHelper::s_oAppHelper->m_oPatientCollection.GetStartPosition();
			int nCount = 0;
			while (NULL != pos)
			{
				CAppHelper::s_oAppHelper->m_oPatientCollection.GetNextAssoc(pos, sPatientName, pPatientDetails);
				if (sPatientName == sToken)
				{
					pPatientDetails->ReadProceduresFromString(sDataToReceive);
				}
			}
			MessageBox(NULL, sDataToReceive, _T("Message From Client"), MB_ICONINFORMATION);
			break;
		}
		case 3: //Image details

			if ( LoadImageFromClient(sImagePage))
			{
				//::PostThreadMessage( 
				//	CAppHelper::s_oAppHelper -> m_pApplication -> m_nThreadID, WM_SELECTIMAGE, NULL, NULL ) ;
			}
			break;
		default :
			break ;
		}
		break ;
	case 2: //Archieve
		ReceiveSerializedData();
		break ;
	default :
		MessageBox(NULL, _T( "Cant Identify the message Mode"), _T("Message From Client"), MB_ICONINFORMATION);
		break ;
	}
	m_bHeaderRecieved = FALSE ;
	m_nMessageMode = 0 ;
	m_nMessageType = 0 ;
}

BOOL CClientSocketThread :: LoadImageFromClient( CString  & sImagePath )
{
	char* buff = new char[m_nMessageSize+1]; 
	int nRead;
	nRead = m_pClientSocket->Receive(buff, m_nMessageSize);
	buff[nRead] = _T('\0'); //terminate the buffer

	sImagePath = "Sample1.jpg";
	FILE* fp = NULL;
	fp = fopen ( "Sample1.jpg", "wb" ) ; //TODO will explain it latter
	if (!fp)
	{
		free(buff);
		return FALSE ;
	}
	
	if (nRead == 0 && nRead == -1)
	{
		return FALSE ;
	}

	if (!fwrite(buff, m_nMessageSize, 1, fp))
	{
		free(buff);
		fclose(fp);
		return 0;
	}
	fclose(fp);
	free(buff);
	return TRUE;
}

void CClientSocketThread :: ReceiveSerializedData ( )
{
	CSocketFile oSocketFile ( m_pClientSocket, TRUE ) ;
	CArchive oArchive ( &oSocketFile, CArchive::Mode::load ) ;

	CPatientDetails* pPatientDetails = new CPatientDetails( ) ;
	pPatientDetails -> Serialize( oArchive ) ;
}
	
void CClientSocketThread :: OnSocketClose ( int nErrorCode )
{
	
	::PostThreadMessage( CAppHelper::s_oAppHelper -> 
		m_oActiveClientThreads[m_sThreadName] -> m_nThreadID, WM_EXITCLIENTTHREAD, NULL, NULL ) ;
	CAppHelper::s_oAppHelper -> m_oActiveClientThreads.RemoveKey ( m_sThreadName ) ;

	delete m_pClientSocket ;
	m_pClientSocket = NULL ;
}

void CClientSocketThread :: OnSocketSend ( int nErrorCode )
{
}

BOOL CClientSocketThread::InitInstance()
{
	m_sThreadName.Format( _T("Thread%d"), ++CClientSocketThread::s_nThreadNumber) ;
	CAppHelper::s_oAppHelper -> m_oActiveClientThreads[m_sThreadName] = this ;

	if ( NULL == m_pClientSocket )
	{
		::PostQuitMessage( -1 ) ;
	}
	m_pClientSocket -> SetSocketOwner( this ) ;
	return TRUE;
}

int CClientSocketThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

void CClientSocketThread::RestriectObjectCreation()
{
	//This is Just an implementation of Pure virtual function in ISocketOwner Interface
}

BEGIN_MESSAGE_MAP(CClientSocketThread, CWinThread)
	ON_THREAD_MESSAGE(WM_EXITCLIENTTHREAD, OnExitThread)
END_MESSAGE_MAP()

void CClientSocketThread :: OnExitThread ( WPARAM wParam, LPARAM lParam ) 
{
	PostQuitMessage( 1 ) ;
}

// CClientSocketThread message handlers
