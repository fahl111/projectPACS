
// SCPProjectView.h : interface of the CSCPProjectView class
//

#pragma once
#include "ServerSockectThread.h"

class CSCPProjectView : public CFormView
{
protected: // create from serialization only
	CSCPProjectView() noexcept;
	DECLARE_DYNCREATE(CSCPProjectView)

public:
#ifdef AFX_DESIGN_TIME
	enum{ IDD = IDD_SCPPROJECT_FORM };
#endif

// Attributes
public:
	CSCPProjectDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct

	/// <summary>
	/// Variable to store the whether the server is started or not
	/// </summary>
	BOOL m_bServerStarted = FALSE ;

	/// <summary>
	/// Variable store the server socket thread
	/// </summary>
	CServerSockectThread* m_pServerSocketThread = NULL ;

// Implementation
public:
	virtual ~CSCPProjectView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnStartserver();
};

#ifndef _DEBUG  // debug version in SCPProjectView.cpp
inline CSCPProjectDoc* CSCPProjectView::GetDocument() const
   { return reinterpret_cast<CSCPProjectDoc*>(m_pDocument); }
#endif

