// ServerSockectThread.cpp : implementation file
//

#include "pch.h"
#include "SCPProject.h"
#include "ServerSockectThread.h"
#include "ClientSocketThread.h"

// CServerSockectThread

IMPLEMENT_DYNCREATE(CServerSockectThread, CWinThread)

CServerSockectThread::CServerSockectThread()
{
}

CServerSockectThread :: CServerSockectThread ( CWnd* pParentWnd )
{
	m_pParentWindow = pParentWnd ;
}


CServerSockectThread::~CServerSockectThread()
{
}

void CServerSockectThread :: OnSocketConnet ( int nErrorCode )
{

}

void CServerSockectThread :: OnSocketAccept ( int nErrorCode )
{
	//CAsyncClientSocket* pClientSocket = new CAsyncClientSocket( ) ;//TODO
	CClientSocket * pClientSocket = new CClientSocket( ) ;//Create a client socket to communicate with the requesting socket

	if (m_pServerSocket->Accept(*pClientSocket)) //Accept the request to new created client socket
	{
		CClientSocketThread* pClientSockectThread = new CClientSocketThread(); //Create a cilent thread to manage the communication
		pClientSockectThread -> m_pClientSocket = pClientSocket ; //Attach or handover the newly created socket to client thread
		pClientSockectThread -> CreateThread( ) ; //Initiate or start the client thread
	}
}

void CServerSockectThread::OnSocketClose(int nErrorCode)
{
	delete m_pServerSocket ;
	m_pServerSocket = NULL ;
	PostQuitMessage( 1 ) ;
}

BOOL CServerSockectThread :: InitInstance ( )
{
	//m_pServerSocket = new CAsyncServerSocket( ) ; //TODO
	m_pServerSocket = new CServerSocket( ) ;

	m_pServerSocket->SetSocketOwner( this ) ;
	BOOL bSuccess = m_pServerSocket -> CreateServerSocket( ) ;
	bSuccess = m_pServerSocket -> BeginListening( ) ;
	return TRUE ;
}

int CServerSockectThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	m_pServerSocket -> Close ( ) ;
	delete m_pServerSocket ;
	m_pServerSocket = NULL ;
	return CWinThread::ExitInstance();
}

void CServerSockectThread::RestriectObjectCreation()
{
	//This is Just an implementation of Pure virtual function in ISocketOwner Interface
}

BEGIN_MESSAGE_MAP(CServerSockectThread, CWinThread)
	ON_THREAD_MESSAGE( WM_EXITSERVERTHREAD, OnExitServerThred )
END_MESSAGE_MAP()

void CServerSockectThread :: OnExitServerThred ( WPARAM wParam, LPARAM lParam )
{
	PostQuitMessage(1);
}

// CServerSockectThread message handlers
