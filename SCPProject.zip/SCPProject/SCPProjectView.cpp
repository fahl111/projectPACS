
// SCPProjectView.cpp : implementation of the CSCPProjectView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "SCPProject.h"
#endif

#include "SCPProjectDoc.h"
#include "SCPProjectView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSCPProjectView

IMPLEMENT_DYNCREATE(CSCPProjectView, CFormView)

BEGIN_MESSAGE_MAP(CSCPProjectView, CFormView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_BN_CLICKED(IDC_BTN_STARTSERVER, &CSCPProjectView::OnBnClickedBtnStartserver)
END_MESSAGE_MAP()

// CSCPProjectView construction/destruction

CSCPProjectView::CSCPProjectView() noexcept
	: CFormView(IDD_SCPPROJECT_FORM)
{
	// TODO: add construction code here

}

CSCPProjectView::~CSCPProjectView()
{
}

void CSCPProjectView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BOOL CSCPProjectView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CSCPProjectView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

void CSCPProjectView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CSCPProjectView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CSCPProjectView diagnostics

#ifdef _DEBUG
void CSCPProjectView::AssertValid() const
{
	CFormView::AssertValid();
}

void CSCPProjectView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CSCPProjectDoc* CSCPProjectView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSCPProjectDoc)));
	return (CSCPProjectDoc*)m_pDocument;
}
#endif //_DEBUG


// CSCPProjectView message handlers


void CSCPProjectView::OnBnClickedBtnStartserver()
{
	if (!m_bServerStarted)
	{
		m_pServerSocketThread = new CServerSockectThread(this);
		m_pServerSocketThread->CreateThread();//Starting the Server Socket thread, this will invoke the thread, InitInstance function - This is  UI Thread can handle events
		SetDlgItemText(IDC_BTN_STARTSERVER, _T("Stop Server"));
		m_bServerStarted = TRUE;
	}
	else
	{
		::PostThreadMessage(m_pServerSocketThread->m_nThreadID, WM_EXITSERVERTHREAD, NULL, NULL);
		SetDlgItemText(IDC_BTN_STARTSERVER, _T("Start Server"));
		m_pServerSocketThread = NULL;
		m_bServerStarted = FALSE;
	}
}
